package com.stockmarket.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {
	/**
	 * 注册
	 */
	public void register(){
		
	}
	/**
	 * 自动注册
	 */
	public void autoRegister(){
		
	}
	
}
