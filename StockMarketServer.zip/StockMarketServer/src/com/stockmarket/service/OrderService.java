
package com.stockmarket.service;

import org.springframework.stereotype.Service;

@Service("orderService")
public class OrderService {
	
}
