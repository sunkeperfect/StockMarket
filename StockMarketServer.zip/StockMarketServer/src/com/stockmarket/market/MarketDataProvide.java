package com.stockmarket.market;

import java.util.ArrayList;

import com.stockmarket.model.Stock;

public class MarketDataProvide {

}
